<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class SubmitForm extends Controller
{
  public function insertform(){
    return view('Aftcreate');
  }
  public function insert(Request $request){
    $email = $request->input('email');
    $description = $request->input('description');
    // $afimage = $request->input('afimage');
    $afimage = $request->file('afimage');
    // $bfimage = $request->input('bfimage');
     $bfimage = $request->file('bfimage');
     //Move Uploaded File
      $destinationPath = 'uploads';
      $afimage->move($destinationPath,$afimage->getClientOriginalName());
      $bfimage->move($destinationPath,$bfimage->getClientOriginalName());
    $data=array('email'=>$email,"des"=>$description,"bfimage"=>$bfimage->getClientOriginalName(),"afimage"=>$afimage->getClientOriginalName());
    DB::table('submitions')->insert($data);
    echo "Record inserted successfully.<br/>";
    echo '<a href = "/">Click Here</a> to go back.';
  }
}

<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class SubmitForm extends Controller
{
  public function insertform(){
    return view('Aftcreate');
  }
  public function insert(Request $request){
    $first_name = $request->input('email');
    $last_name = $request->input('description');
    $city_name = $request->input('afimage');
    $email = $request->input('bfimage');
    $data=array('email'=>$first_name,"des"=>$last_name,"bfimage"=>$city_name,"afimage"=>$email);
    DB::table('submitions')->insert($data);
    echo "Record inserted successfully.<br/>";
    echo '<a href = "/">Click Here</a> to go back.';
  }
}

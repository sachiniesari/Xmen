@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                    You are logged in!
                </div>

                <div class="content">
                    <div class="title m-b-md">
                        Submitions
                    </div>
                    <?php

                      $users = DB::table('submitions')->select('email','des','afimage','bfimage')->get();
                     ?>
                     <table  class="table table-striped table-bordered" cellspacing="0" width="100%">
                        <thead>
                            <tr>
                              <th>Email</th>

                              <th>Description</th>

                              <th>Before Image</th>

                              <th>After Image</th>
                            </tr>
                            @foreach($users as $value)

                            <tr>

                            <td>{{ $value->email }}</td>

                            <td>{{ $value->des }}</td>

                            <td>{{ $value->bfimage }}</td>

                            <td>{{ $value->afimage }}</td>


                            </tr>

                            @endforeach

                        </thead>


                    </table>

                </div>

            </div>
        </div>
    </div>
</div>
@endsection

@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div >
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                    You are logged in!
                </div>

                <div class="card-body">
                    <div class="title m-b-md">
                        Submitions

                    <?php

                      $users = DB::table('submitions')->select('email','des','afimage','bfimage')->get();
                     ?>
                     <table  class="table table-hover" cellspacing="0" width="75%">
                        <thead>
                            <tr>
                              <th>Email</th>

                              <th>Description</th>

                              <th>Before Image</th>

                              <th>After Image</th>
                              <th>Accept</th>
                              <th>Reject</th>
                            </tr>
                            @foreach($users as $value)

                            <tr>

                            <td>{{ $value->email }}</td>

                            <td>{{ $value->des }}</td>

                            <td><img src="{{ 'uploads/'.$value->bfimage }}" style="width:50px;height:50px"></td>

                            <td><img src="{{ 'uploads/'.$value->afimage }}" style="width:50px;height:50px"></td>

                            <td><input type="submit" value="Accept"></td>

                            <td><input type="submit" value="Reject"></td>

                            </tr>

                            @endforeach

                        </thead>


                    </table>
                    </div>

                </div>

            </div>
        </div>
    </div>
</div>
@endsection

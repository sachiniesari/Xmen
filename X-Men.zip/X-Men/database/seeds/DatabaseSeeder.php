<!-- Laravel includes a simple method of seeding your database with test data using seed classes. All seed classes are 
stored in the database/seeds directory. Seed classes may have any name you wish, but probably should follow some
sensible convention, such as UsersTableSeeder, etc. By default, a DatabaseSeeder class is defined for you. From this class,
you may use the call method to run other seed classes, allowing you to control the seeding order. -->

<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
      DB::table('users')->insert([
          'name' => Str::random(10),
          'email' => Str::random(10).'@gmail.com',
          'password' => bcrypt('password'),
      ]);
    }
}

<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>

        <!-- Styles -->
        <style>
            html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
            }

            .title {
                font-size: 84px;
            }

            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 13px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 30px;
            }
        </style>
    </head>
    <body>
        <div class="flex-center position-ref full-height">
            <?php if(Route::has('login')): ?>
                <div class="top-right links">
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(url('/home')); ?>">Home</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>">Login</a>

                        <?php if(Route::has('register')): ?>
                            <!-- <a href="<?php echo e(route('register')); ?>">Register</a> -->
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            <form action = "/create" method = "post" enctype="multipart/form-data">
            <input type = "hidden" name = "_token" value = "<?php echo csrf_token(); ?>">
            <table class="table table-striped">
              <tr>
                <td>Email</td>
                <td><input type='email' name='email' pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$"/></td>
              <tr>
                <td>Description</td>
                <td><input type="text" name='description'/></td>
              </tr>
              <tr>
                <td>Before Image</td>
                <td><input type="file" name='afimage'/></td>
              </tr>
              <tr>
                <td>After Image</td>
                <td><input type="file" name='bfimage'/></td>
              </tr>
              </tr>
              <tr>
                <td colspan = '2'>
                <input type = 'submit' value = "Add student"/>
                </td>
              </tr>
            </table>
            </form>

        </div>
    </body>
<script type="text/javascript">
$('input[type=afimage]').change(function () {
    console.log(this.files[0].mozFullPath);
});
}
</script>
</html>
<?php /**PATH C:\Users\Imesha Anuruddha\Documents\Laravel\X-Men\resources\views/welcome.blade.php ENDPATH**/ ?>
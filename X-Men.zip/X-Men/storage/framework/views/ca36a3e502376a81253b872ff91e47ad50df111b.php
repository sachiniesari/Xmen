<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    You are logged in!
                </div>

                <div class="content">
                    <div class="title m-b-md">
                        Submitions
                    </div>
                    <?php

                      $users = DB::table('submitions')->select('email','des','afimage','bfimage')->get();
                     ?>
                     <table  class="table table-striped table-bordered" cellspacing="0" width="100%">
                        <thead>
                            <tr>
                              <th>Email</th>

                              <th>Description</th>

                              <th>Before Image</th>

                              <th>After Image</th>
                            </tr>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>

                            <td><?php echo e($value->email); ?></td>

                            <td><?php echo e($value->des); ?></td>

                            <td><?php echo e($value->bfimage); ?></td>

                            <td><?php echo e($value->afimage); ?></td>


                            </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </thead>


                    </table>

                </div>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Imesha Anuruddha\Documents\Laravel\X-Men\resources\views/home.blade.php ENDPATH**/ ?>